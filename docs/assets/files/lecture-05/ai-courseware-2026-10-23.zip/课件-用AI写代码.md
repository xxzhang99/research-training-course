# 用 AI 写代码：只依据论文复现 DGI

## 0. 本课导览

**学习目标**：用“说清需求 → 先出计划 → 确认后实现 → 运行 → 核验 → 提交”的循环，借助 AI 只依据论文实现一个方法；把论文没写清楚的地方列出来自己决定；每一步存成新文件，看得到 AI 每次改了什么；写完后再用官方实现对照、查错；最后用一个 Skill 把整套流程搬到另一篇论文上。

**一句话**：AI 可以写代码、跑实验、写汇总，研究问题、判定标准和结论由你定，每个数字都要回到日志和 results.csv 核对。

| 部分 | 内容 |
|---|---|
| 第一部分 Vibe Coding | 是什么、工具、四条心法、工作循环、六条技法 |
| 第二部分 只依据论文复现 DGI | 演示 1–8：抽规格、建立参照、分步写代码、排查异常、交给智能体、判读、写完再对照、收工 |
| 第三部分 一键复现 | 演示 9：用 Skill 只依据论文复现 GRACE |
| 总结 | 一个循环、人要守住的三处、本课 AI 出过的错 |

## 第一部分 Vibe Coding

### 1.1 什么是 Vibe Coding

2025 年 2 月，OpenAI 联合创始人、前特斯拉 AI 总监 Andrej Karpathy 在社交媒体上提出“vibe coding”（氛围编程）：完全沉浸在感觉里，拥抱指数级的变化，甚至忘记代码的存在。同年 11 月，柯林斯词典把“Vibe Coding”选为年度词汇，定义是：使用人工智能、通过自然语言描述来生成计算机代码的方式。2025 年 3 月，Y Combinator CEO Garry Tan 透露，当期孵化的创业公司中有 25% 报告其 95% 的代码由 AI 生成。

从 Coder 变成 Commander，变的是手上的活：

| 过去 | 现在 |
|---|---|
| 记住语法规则 | 把需求描述清楚 |
| 手写代码 | 判断代码对不对 |
| 调试找 Bug | 把问题描述完整，让 AI 修 |
| 阅读技术文档 | 知道什么该问、什么该查 |

没变的是三件事：你要知道自己想做什么，要能看出结果好不好，要有一步步排查问题的思路。缺了这三件，AI 只会让错误来得更快。

### 1.2 工具

![AI 编程工具全景图（2025 年版）](images/vibe_image1.png)

AI 编程工具分五类：对话式 AI、AI 代码编辑器、IDE 插件、网页版一站式工具、命令行工具。做科研实验，用代码编辑器（如 Cursor）或命令行智能体（如 Claude Code、Codex）：编辑器里改动以 diff 呈现，便于逐行审；命令行智能体适合按任务书连续执行。

**Cursor 上手**：安装登录后，在代理或 VPN 环境下连接不稳定，到 Settings → Network 把 HTTP Compatibility Mode 改为 HTTP/1.1，然后重启。对话框左下角切换 Agent / Plan 模式。

| 网络设置：HTTP Compatibility Mode | 对话框：切换 Agent / Plan 模式 |
|---|---|
| ![Cursor 网络设置](images/vibe_image2.png) | ![Cursor 对话框](images/vibe_image3.png) |

两个常用插件：GitLens 和 Git Graph 看 AI 改了哪些行、提交了什么；Remote - SSH 连接实验室服务器跑实验。

### 1.3 四条心法

- **上下文为王**：输入什么质量，输出就是什么质量。
- **目的主导**：每一步都围绕要验证的问题展开。
- **不写无关代码**：无关内容会干扰模型，也增加审查负担。
- **先做最小可行版本**：用最小的投入验证核心假设，再扩展。

### 1.4 一个工作循环

每个演示都按下面这个循环进行：

```mermaid
flowchart LR
    A["说清需求"] --> B["AI 先出计划"]
    B --> C["确认后实现"]
    C --> D["运行"]
    D --> E["核验"]
    E --> F["提交"]
    F --> A
```

“说清需求”用六个要素：

| 要素 | 写什么 |
|---|---|
| 背景 | 项目现在是什么状态、有哪些条件限制（如只有 CPU、时间预算） |
| 目标 | 这一步要验证或准备什么，一句话 |
| 输入输出 | 读哪些文件，产出哪些文件、什么格式 |
| 任务 | 逐条列出要做的事 |
| 不做什么 | 不改哪些代码、不装依赖、不做任务之外的“顺手优化” |
| 验收 | 怎么证明做对了：`git diff` 的范围、要运行的命令、预期输出 |

### 1.5 六条技法

| 技法 | 做法 | 本课对应 |
|---|---|---|
| 先规划后执行 | 让 AI 先出计划，确认理解无误再动手；Cursor 用 Shift+Tab 从 Plan Mode 切到 Agent Mode | 演示 1 先出规格表；演示 3 先出 6 步计划；演示 5 试跑后停下 |
| 需求写明确 | 按六要素写，告诉 AI 要做什么、不做什么，不让它猜 | 演示 3 “帮我复现 DGI”与六要素需求对比 |
| 小步快跑 | 每次只完成一个最小单元，完成后立即运行和核验；每一步存成新文件，旧文件保留 | 演示 3 分 6 步，每步一个文件、一次验收、一次提交 |
| 管理上下文 | 长会话的上下文总结会丢信息；AI 忘记规范时，重新给出项目说明书或新开会话 | AGENTS.md 每次自动读入；演示 8 新对话写报告 |
| 报错给全信息 | 报错给出出错文件、运行命令、完整 Traceback；数字异常给出现象、预期和已确认的部分；同一个问题修三次不成功，停下重新规划 | 演示 4、演示 7 |
| 版本控制 | 每完成一个最小单元提交一次，相邻两步的 diff 存下来；AI 改坏了就回到上一个文件 | 演示 3 的 steps/ 与 diffs/；演示 7 的变体放进新文件 |

项目说明书的文件名因工具而异：Codex 读 `AGENTS.md`，Claude Code 读 `CLAUDE.md`，Cursor 读 `.cursorrules` 或项目规则。本课用 `AGENTS.md`。

## 第二部分 只依据论文复现 DGI

**研究问题**：只依据论文 Deep Graph Infomax（Veličković 等，ICLR 2019，arXiv:1809.10341）用纯 PyTorch 实现 DGI，能否在 Cora 上达到论文表 2 报告的 82.3 ± 0.6%。

**为什么只依据论文**：科研中常常遇到方法只有论文、没有可用代码的情况：作者没有放出代码，代码只有其他框架的版本，或者年代太久已经跑不起来，这时只能照着论文自己写。即使有官方代码，独立实现一遍也有价值：它检验的是论文写下的内容够不够复现结果，也是真正弄懂一个方法的办法。如果只是要用这个方法，首选还是直接运行和修改官方代码。

**做法**：写代码阶段不读、不粘贴作者仓库和 PyG 中 DGI、GCN 的源码，PyG 只用来加载数据。官方实现只在两处使用：演示 2 只运行、不读代码，拿到对照数字；演示 7 代码写完以后，用它查错。

论文一般不会把实现细节写全。让 AI 按论文写代码，最常见的两个问题是：直接调用库里现成的实现，以及用常见默认值补上论文没写的设置。下面 8 个演示围绕 DGI 的复现展开，依次处理这两个问题。

Cora 是论文引用网络：2,708 个节点，1,433 维词袋特征，7 个类别，标准划分为训练 140、验证 500、测试 1,000 个节点。

| 演示 | 这一圈做什么 | 这一圈的重点 |
|---|---|---|
| 1 抽规格 | 从论文抽出实现规格表和待决定清单 | 论文没写的，由人决定 |
| 2 建立参照 | 运行官方实现，只拿数字 | 先有对照，再写代码 |
| 3 分步写代码 | 差需求与六要素需求对比；6 步实现，每步一个新文件 | 每次改动都看得见、退得回 |
| 4 排查异常 | 验收数字与预期不符时怎么问 | 不改代码去凑数字 |
| 5 交给智能体 | AGENTS.md + plan.md，试跑停下，再正式运行 | 检查点由人确认 |
| 6 判读 | 按预设标准判读，不跟着提问的语气走 | AI 不能替你下结论 |
| 7 写完再对照 | 数据泄漏检查、差分测试、对照作者仓库、变体实验 | 写完以后用官方代码查错 |
| 8 收工 | 新对话写报告 | 每个数字都有出处 |

### 2.1 演示 1　抽规格

写代码之前，先把论文整理成一张“实现规格表”：每个模块论文怎么写的、写在哪里。同时列一张“待决定清单”，把论文没有写、但写代码时必须确定的地方都列出来。这张清单由人来填。AI 整理得快，但可能把论文没写的地方用默认值补上，表里看不出来，所以要单独列清单。

**输入**

```text
【背景】我要只依据论文复现 DGI 在 Cora 上的节点分类结果，不参考任何已有实现。
【材料】【DGI 论文全文，arXiv:1809.10341v2】
【任务】整理实现规格表：每个模块写清论文怎么说、出自哪一节或哪个公式；再列出待决定清单：论文没有说明、但写代码必须确定的地方。
【约束】只依据论文；每项注明章节或公式号；论文没写的不要用常见默认值补上，列入待决定清单。
【格式】两张表。规格表：模块 | 论文写法 | 出处；待决定清单：序号 | 问题 | 可选做法 | 影响。
```

**模型输出**

> ## 实现规格表（只依据论文，arXiv:1809.10341v2）
>
> | 模块 | 论文写法 | 出处 |
> |---|---|---|
> | 编码器 | 一层 GCN：E(X, A) = σ(D̂^(-1/2) Â D̂^(-1/2) X Θ) | 4.2 节，式 (3) |
> | 扰动函数 | 邻接矩阵不变（Ã = A），特征按行打乱（row-wise shuffling of X） | 4.2 节 |
> | 读出函数 | R(H) = σ((1/N) Σ_i h_i)，σ 为 sigmoid | 4.2 节，式 (9) |
> | 判别器 | D(h_i, s) = σ(h_iᵀ W s)，W 为可学习矩阵 | 4.2 节，式 (10) |
> | 损失 | 正样本 N 个、负样本 M 个的二元交叉熵，取 1/(N+M) 平均 | 3.2 节，式 (1) |
> | … | … | … |
>
> ## 待决定清单（论文未说明）
>
> | 序号 | 问题 | 可选做法 | 影响 |
> |---|---|---|---|
> | Q1 | 输入特征是否归一化 | 不处理（原始 0/1 词袋）；按行归一化 | 改变 XΘ 的数值尺度 |
> | Q2 | GCN 层是否带偏置 | 不带，与式 (3) 一致；带 | 式 (3) 中没有偏置项 |
> | Q3 | PReLU 的参数个数 | 一个共享参数；每个通道一个 | 论文只写“PReLU” |
> | Q4 | 判别器是否带偏置 | 不带，与式 (10) 一致；带 | 式 (10) 中没有偏置项 |
> | Q5 | 最大训练轮数 | 论文只给了早停规则，需要设一个上限 | 早停没有触发时的保护 |
> | Q6 | 逻辑回归的实现与正则 | 求解器、正则系数、迭代次数都未说明 | 直接影响测试准确率 |
> | Q7 | 训练、测试节点的划分 | 4.1 节只写“按 Kipf & Welling 的设置”，没有写数量 | 需要确认是标准划分 140 / 500 / 1,000 |
> | Q8 | 50 次运行的含义 | 每次都重新训练 DGI，还是训练一次后重复逻辑回归 | 决定标准差的含义 |
>
> 待决定清单的 8 项需要你决定后才能写代码。

**核验**

- ✓ 16 项规格的出处逐项回到论文核对，章节和公式号全部正确：式 (3) 在 4.2 节，式 (9)、(10) 在 4.2 节末尾，式 (1) 在 3.2 节，82.3 ± 0.6% 在表 2。
- ✓ 待决定清单里的 8 项，在论文全文中搜索确实没有说明，例如全文没有出现特征归一化、最大轮数、逻辑回归的正则设置。
- ✓ 没有出现“通常设为”“一般取”这类用默认值补上的说法。

**人工决定**：写代码之前，把 8 项逐一填上，存为 [decisions.md](dgi_paper/decisions.md)，同时写定判定标准：

```markdown
# 待决定清单：人工决定（写代码之前完成）

| 序号 | 问题 | 决定 | 理由 |
|---|---|---|---|
| Q1 | 输入特征是否归一化 | 不处理，用原始 0/1 词袋 | 论文没有写，不额外加预处理 |
| Q2 | GCN 层是否带偏置 | 不带 | 与式 (3) 一致 |
| Q3 | PReLU 的参数个数 | 一个共享参数（`nn.PReLU()` 默认） | 论文只写 PReLU，取最简单的形式 |
| Q4 | 判别器是否带偏置 | 不带 | 与式 (10) 一致 |
| Q5 | 最大训练轮数 | 1,000 轮 | 只作保护，正常应由早停结束 |
| Q6 | 逻辑回归 | sklearn `LogisticRegression`，默认 lbfgs、C = 1.0，`max_iter=1000`，只用训练节点拟合 | 论文只写“简单的逻辑回归”，用默认设置，不调参 |
| Q7 | 划分 | Planetoid 标准划分：训练 140 / 验证 500 / 测试 1,000 | Kipf & Welling 的设置 |
| Q8 | 运行次数 | 每次重新训练 DGI；课程预算内每组 5 次，种子 0–4 | 论文 50 次，算力有限时减少次数，标准差含义不变 |

判定标准（运行前写定）：

1. 5 个种子的测试准确率均值落在 81.7%–82.9%（论文 82.3 ± 0.6%），判为“达到论文水平”。
2. 与 PyG 官方实现（82.08 ± 0.67%，5 个种子）的均值之差不超过两组标准差之和，判为“与官方实现一致”。
```

### 2.2 演示 2　建立参照

写代码之前，先把官方实现原样跑一遍，记下这台电脑、这个环境下的结果。这一步只运行、不读代码。有了这个数，后面结果对不上时，能分清是代码写错了，还是环境本来就跑不到论文的数。

**输入**

```text
【背景】dgi_demo/dgi_cora.py 是 PyG 官方示例 infomax_transductive.py 的原样拷贝，已提交到 Git。
【任务】不做任何改动，运行一次 dgi_cora.py，报告最后一行的测试准确率和运行时间。
【约束】只运行、不阅读实现代码；不改任何文件；不装、不升级依赖；报错就停下报告。
【格式】给出运行命令、输出的最后 3 行、用时。
```

**模型输出**

> 已原样运行，没有修改任何文件。
>
> - 命令：`python dgi_cora.py`（使用 `.venv` 中的 Python 3.13，torch 2.14.1，torch_geometric 2.8.0）
> - 用时：22.2 秒（`/usr/bin/time` 的 real）
> - 输出的最后 3 行：
>
> ```
> Epoch: 299, Loss: 0.0092
> Epoch: 300, Loss: 0.0085
> Accuracy: 0.8290
> ```
>
> 测试准确率 82.90%。示例代码没有固定随机种子，再运行一次结果可能不同。

**核验**

- ✓ 运行日志 [runs/02_original_run.log](runs/02_original_run.log) 第 301 行为 `Accuracy: 0.8290`，`/usr/bin/time` 记录 real 22.20 秒。
- ✓ 同一台电脑上 5 个种子的结果为 82.08 ± 0.67%（[dgi_demo/results.csv](dgi_demo/results.csv)），作为演示 5、6 的对照组。

### 2.3 演示 3　分步写代码

**输入（差需求）**

```text
帮我复现 DGI。
```

**模型输出**

> 好的，用 PyTorch Geometric 自带的 `DeepGraphInfomax` 可以很快复现。代码保存为 `dgi_bad.py`：
>
> ```python
> from torch_geometric.nn import DeepGraphInfomax, GCNConv
> ...
> model = DeepGraphInfomax(
>     hidden_channels=512,
>     encoder=Encoder(dataset.num_features, 512),
>     summary=lambda z, *args, **kwargs: z.mean(dim=0).sigmoid(),
>     corruption=corruption,
> )
> optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
> for epoch in range(1, 301):
>     ...
> acc = model.test(z[data.train_mask], data.y[data.train_mask],
>                  z[data.test_mask], data.y[data.test_mask], max_iter=150)
> ```
>
> 编码器用一层 `GCNConv` 加 PReLU，读出函数是节点表示均值再过 sigmoid，扰动函数打乱节点特征，训练 300 轮后用逻辑回归评测。直接运行 `python dgi_bad.py` 即可，Cora 上一般能到 82% 左右，和论文报告的结果接近。

**核验**

- ✓ 代码能跑，seed 0 的准确率为 82.50%，见 [dgi_paper/runs/03_bad_run.txt](dgi_paper/runs/03_bad_run.txt)。
- ✗ [dgi_bad.py:6](dgi_paper/scratch_bad/dgi_bad.py#L6) 导入 `DeepGraphInfomax, GCNConv`，[dgi_bad.py:27-32](dgi_paper/scratch_bad/dgi_bad.py#L27-L32) 直接调用 `DeepGraphInfomax(...)`：这是调用库，不是复现。
- ✗ [dgi_bad.py:35-41](dgi_paper/scratch_bad/dgi_bad.py#L35-L41) 训练固定 300 轮，论文写的是按训练损失早停，耐心值 20；全文没有固定随机种子，也没有记录结果。
- 处理：这份代码保留在 [scratch_bad/dgi_bad.py](dgi_paper/scratch_bad/dgi_bad.py)，不进入正式实验。

准确率和论文接近，但这份代码调用的是库里的 DGI，没有按论文实现。需求里要写清依据哪些材料、不能做什么、每一步怎么验收。

**输入（六要素需求，第 1 轮：只出计划）**

```text
【背景】项目根目录有 spec.md（实现规格表）和 decisions.md（论文未说明之处的决定），均已提交到 Git。
【目标】只依据论文用纯 PyTorch 实现 DGI，在 Cora 上复现 82.3 ± 0.6%。
【输入输出】按 spec.md 和 decisions.md 实现；分步写在 steps/ 下，每一步一个新文件，后一步复制前一步再改，旧文件保留；相邻两步的 diff 存进 diffs/。
【任务】数据与归一化邻接矩阵；GCN 层与编码器；读出、扰动、判别器与损失；训练与早停；线性评测；种子与结果记录。
【不做什么】不读、不粘贴作者仓库和 PyG 中 DGI、GCN 的源码，PyG 只用来加载数据；论文没写的按 decisions.md 执行，没有的停下问我；不装依赖。
【验收】每一步写出可以运行检查的验收标准：形状、数值范围、与公式对应的特殊值。
先列出分几步、每步新建什么文件、实现什么、对应论文哪一处、怎么验收，不要写代码。
```

**模型输出**

> 计划分 6 步实现，每一步新建一个文件，后一步复制前一步再增加内容，旧文件保留不动。每一步都先运行、按验收自查，再生成 diff 并提交。
>
> | 步骤 | 新文件 | 实现内容 | 论文出处 | 验收 |
> |---|---|---|---|---|
> | 1 | `steps/step1_data.py` | 用 Planetoid 加载 Cora；自己构造 Â = A + I 和 D̂^(-1/2) Â D̂^(-1/2)，存为稀疏矩阵 | 式 (3) | 节点 2,708；Â 非零元 = 边数 10,556 + 自环 2,708；Â 对称、对角线全为 1；归一化矩阵最大特征值约为 1；划分 140 / 500 / 1,000 |
> | 2 | `steps/step2_gcn.py` | 自己写 GCN 层：XΘ 再左乘归一化矩阵，Θ 用 Glorot 初始化、不带偏置（Q2）；编码器 = GCN 层 + PReLU（Q3） | 式 (3)、4.2 节 | 输出形状 (2708, 512)；参数量 1433 × 512 + 1 = 733,697 |
> | 3 | `steps/step3_dgi.py` | 读出函数 sigmoid(均值)；扰动函数按行打乱 X；双线性判别器 W 不带偏置（Q4）；式 (1) 的二元交叉熵 | 式 (9)、(10)、(1)、4.2 节 | 初始化时损失约为 ln 2 = 0.6931；打乱后仍在原位的行占比约 1/N；一次反向传播后所有参数都有梯度 |
> | 4 | `steps/step4_train.py` | Adam，学习率 0.001；按训练损失早停，耐心值 20；最多 1,000 轮（Q5）；保留损失最低时的参数 | 4.2 节 | 打印停止轮次和最低损失；早停在 1,000 轮之前触发 |
> | 5 | `steps/step5_eval.py` | 冻结编码器，用原图得到表示；逻辑回归只用 140 个训练节点拟合，在 1,000 个测试节点上评测一次（Q6、Q7） | 4 节开头、4.3 节 | 打印测试准确率；测试集只出现在最后一次评分 |
> | 6 | `steps/step6_run.py` | 加 `--seed`，固定随机种子；结果追加写入 results.csv；为批量运行做准备 | — | 同一种子运行两次结果相同 |
>
> 需要你确认的一点：式 (1) 的二元交叉熵，我打算用 `BCEWithLogitsLoss` 作用在 h_iᵀ W s 上，而不是先过 sigmoid 再算 log。数学上与式 (1) 等价，数值上更稳定。

**核验**

- ✓ 6 步覆盖了规格表的全部模块，每一步都对应到论文的公式或章节。
- ✓ 每一步的验收都能用运行结果检查，例如“Â 非零元 = 10,556 + 2,708”“参数量 733,697”。
- ✓ 计划提出用 `BCEWithLogitsLoss` 代替“先 sigmoid 再取 log”，两者数学上等价，需要人确认。
- 人工确认：同意 6 步计划和 `BCEWithLogitsLoss` 的写法。

**输入（第 2 轮：逐步实现）**

```text
确认，按计划逐步实现。每一步：新建文件 → 运行 → 按验收自查 → 生成 diff → 提交。验收不符时先查清原因，不要改代码去凑数字。
```

**模型输出**

> 6 步已完成，相邻两步的 diff 在 `diffs/`。
>
> | 步骤 | 文件（行数） | 验收结果 | 提交 |
> |---|---|---|---|
> | 1 | `step1_data.py`（48） | 节点 2,708；Â 非零元 13,264 = 10,556 + 2,708；Â 对称、对角线全为 1；最大特征值 1.0000；划分 140 / 500 / 1,000 | `step1: load Cora, build normalized adjacency (eq. 3)` |
> | 2 | `step2_gcn.py`（67） | 输出 (2708, 512)；参数量 733,697，只有 `gcn.theta` 和 `act.weight`，没有偏置 | `step2: GCN layer (no bias) + PReLU encoder (eq. 3)` |
> | 3 | `step3_dgi.py`（118） | 打分形状 (2708,)；打乱后仍在原位的行占比 0.00037 = 1/N；3 个参数都有梯度；**初始损失 0.7233，与预期的 0.6931 不符，见下** | `step3: readout (eq. 9), corruption, bilinear discriminator (eq. 10), BCE loss (eq. 1)` |
> | 4 | `step4_train.py`（138） | seed 0 第 242 轮早停，最低损失 0.0049 出现在第 222 轮，6.0 秒 | `step4: Adam lr 0.001, early stopping on training loss, patience 20` |
> | 5 | `step5_eval.py`（154） | seed 0 测试准确率 82.00% | `step5: linear evaluation with logistic regression (train 140 / test 1000)` |
> | 6 | `step6_run.py`（175） | seed 0 连续运行两次，均为 0.8200；自查产生的 results.csv 已删除 | `step6: --seed, fixed seeds, append results.csv` |
>
> **第 3 步的偏差**：计划中写的验收是“初始损失约为 ln 2”，实际为 0.7233。单独检查了一次：初始化时打分的均值为 0.0786、标准差为 0.5081，打分不全为 0 时二元交叉熵会高于 ln 2；把打分全部置 0，损失正好是 0.6931。结论：损失公式没有写错，是验收标准写得不够准确，应为“打分为 0 时损失等于 ln 2”。检查记录在 `runs/step3_loss_check.txt`。

**核验**

- ✓ 6 个验收输出逐一重新运行，与回报一致，见 [dgi_paper/runs/](dgi_paper/runs/) 下的 step1.txt 至 step6_twice.txt。
- ✓ 第 3 步的验收不符（初始损失 0.7233），回报中给出了检查过程，见演示 4。

**代码与提交记录**

每一步一个文件，每个版本都能单独打开、单独运行：

```text
dgi_paper/
├── spec.md              实现规格表（演示 1）
├── decisions.md         待决定清单的人工决定（演示 1）
├── AGENTS.md            项目说明书
├── steps/
│   ├── step1_data.py        48 行  加载 Cora，构造归一化邻接矩阵
│   ├── step2_gcn.py         67 行  + GCN 层与编码器
│   ├── step3_dgi.py        118 行  + 读出、扰动、判别器、损失
│   ├── step4_train.py      138 行  + 训练与早停
│   ├── step5_eval.py       154 行  + 线性评测
│   ├── step6_run.py        175 行  + 种子与结果记录（正式实验用这一版）
│   └── step7_variants.py   186 行  + 作者仓库设置的开关（演示 7）
├── diffs/               相邻两步的 diff，如 step3_vs_step2.diff
├── checks/              写完后的检查脚本（演示 7）
└── scratch_bad/         差需求得到的代码，不进入正式实验
```

各步骤新增的代码：

| 步骤 | 文件 | 这一步新增的代码 |
|---|---|---|
| 1 | [step1_data.py](dgi_paper/steps/step1_data.py) | 加载数据 [step1_data.py:14-16](dgi_paper/steps/step1_data.py#L14-L16)；归一化邻接矩阵 [step1_data.py:19-30](dgi_paper/steps/step1_data.py#L19-L30) |
| 2 | [step2_gcn.py](dgi_paper/steps/step2_gcn.py) | GCN 层 [step2_gcn.py:34-43](dgi_paper/steps/step2_gcn.py#L34-L43)；编码器 [step2_gcn.py:46-55](dgi_paper/steps/step2_gcn.py#L46-L55) |
| 3 | [step3_dgi.py](dgi_paper/steps/step3_dgi.py) | 读出 [step3_dgi.py:59-61](dgi_paper/steps/step3_dgi.py#L59-L61)；扰动 [step3_dgi.py:64-66](dgi_paper/steps/step3_dgi.py#L64-L66)；判别器 [step3_dgi.py:69-79](dgi_paper/steps/step3_dgi.py#L69-L79)；DGI 与损失 [step3_dgi.py:82-102](dgi_paper/steps/step3_dgi.py#L82-L102) |
| 4 | [step4_train.py](dgi_paper/steps/step4_train.py) | 训练与早停 [step4_train.py:107-127](dgi_paper/steps/step4_train.py#L107-L127) |
| 5 | [step5_eval.py](dgi_paper/steps/step5_eval.py) | 线性评测 [step5_eval.py:134-141](dgi_paper/steps/step5_eval.py#L134-L141) |
| 6 | [step6_run.py](dgi_paper/steps/step6_run.py) | 命令行参数与固定种子 [step6_run.py:152-158](dgi_paper/steps/step6_run.py#L152-L158)；结果追加写入 results.csv [step6_run.py:169-175](dgi_paper/steps/step6_run.py#L169-L175) |

以第 3 步为例，diff 只有新增的读出、扰动、判别器和损失，以及改写的说明和 `__main__`（[diffs/step3_vs_step2.diff](dgi_paper/diffs/step3_vs_step2.diff)，新增 46 行、删除 8 行）。判别器那一段在 [step3_dgi.py:69-79](dgi_paper/steps/step3_dgi.py#L69-L79)：第 75–76 行定义 W 并按论文用 Glorot 初始化，第 78–79 行计算打分 h_iᵀ W s：

```python
class Discriminator(nn.Module):
    """式 (10)：D(h_i, s) = σ(h_iᵀ W s)，W 用 Glorot 初始化，不带偏置（decisions.md Q4）。
    这里返回 sigmoid 之前的打分 h_iᵀ W s，sigmoid 放进损失里计算。"""

    def __init__(self, hidden):
        super().__init__()
        self.w = nn.Parameter(torch.empty(hidden, hidden))
        nn.init.xavier_uniform_(self.w)

    def forward(self, h, s):
        return h @ (self.w @ s)
```

提交记录：

```text
24c5970 step5: linear evaluation with logistic regression (train 140 / test 1000)
fbb212f step4: Adam lr 0.001, early stopping on training loss, patience 20
353184c step3: readout (eq. 9), corruption, bilinear discriminator (eq. 10), BCE loss (eq. 1)
c9d0019 step2: GCN layer (no bias) + PReLU encoder (eq. 3)
380a36e step1: load Cora, build normalized adjacency (eq. 3)
578c896 paper, spec.md, decisions.md, AGENTS.md
```

### 2.4 演示 4　排查异常

第 3 步的验收写的是“初始化时损失约为 ln 2 = 0.6931”，实际跑出 0.7233。代码不报错，只是一个数字和预期不一样。

**输入（只要结果的问法）**

```text
初始损失应该是 0.6931，现在是 0.7233，帮我改对。
```

**模型输出**

> 把判别器的权重矩阵 W 初始化为全零即可。打分 h_iᵀ W s 在初始化时全部为 0，sigmoid 后正负样本的概率都是 0.5，式 (1) 的损失正好等于 ln 2 = 0.6931。
>
> 修改 `Discriminator.__init__`：
>
> ```python
> self.w = nn.Parameter(torch.zeros(hidden, hidden))
> ```
>
> 改完后重新运行 `step3_dgi.py`，初始损失就是 0.6931。

**核验**

- ✗ 这个改法能让数字变成 0.6931，但论文 4.2 节写的是 Glorot 初始化，对应 [step3_dgi.py:76](dgi_paper/steps/step3_dgi.py#L76)；把 W 置 0 等于为了凑一个验收数字去改方法。
- ✗ 回答默认“0.6931 是对的”，没有检查这个预期本身是否成立。

**输入（给全信息）**

```text
【现象】steps/step3_dgi.py 初始化后（seed 0）第一次前向的损失为 0.7233。我预期约为 ln 2 = 0.6931，理由是初始化时判别器应该分不出正负样本。
【相关代码】【step3_dgi.py 第 59–104 行：readout、corruption、Discriminator、DGI.loss】
【已经确认】打分形状为 (2708,)，正负样本各 2,708 个；3 个参数都有梯度；扰动后仍在原位的行占 1/N。
【要求】先列出可能的原因并排序，说明怎么验证。不要改文件，也不要为了让损失等于 0.6931 去改初始化。
```

**模型输出**

> **可能的原因（按可能性排序）**
>
> | 排序 | 可能原因 | 依据 | 怎么验证 |
> |---|---|---|---|
> | 1 | 不是错误：“初始损失等于 ln 2”只在打分全为 0 时成立。Glorot 初始化后 h_iᵀ W s 不为 0，正负样本的打分有一定离散度，二元交叉熵会高于 ln 2 | 式 (1) 对单个样本是 log(1 + e^(−z)) 或 log(1 + e^z)，它在 z = 0 处取 ln 2，且是凸函数，打分有离散度时平均值必然大于 ln 2 | 打印初始打分的均值和标准差；把打分全部置 0 再算一次损失，应正好为 0.6931 |
> | 2 | 正负样本标签写反 | 标签写反时，损失同样在 ln 2 附近，靠初始损失分辨不出来 | 训练几十轮后损失应明显下降；写反时损失会上升 |
> | 3 | 损失没有按 N + M 平均，而是求和或只对一半取平均 | 式 (1) 的系数是 1/(N + M) | 打印 logits 的长度应为 2N = 5,416；把 `BCEWithLogitsLoss` 换成手写的式 (1) 对比 |
>
> **建议**：先做第 1 项验证。如果打分置 0 后损失等于 0.6931，就说明代码正确，需要改的是验收标准，不是代码。初始化保持 Glorot（4.2 节）。

**核验**

按回答的三条建议逐一验证（[runs/step3_loss_check.txt](dgi_paper/runs/step3_loss_check.txt)、[runs/04_verify.txt](dgi_paper/runs/04_verify.txt)）：

| 假设 | 验证 | 结果 |
|---|---|---|
| 1 打分不为 0，损失自然高于 ln 2 | 打印初始打分；把打分全部置 0 再算 | 打分均值 0.0786、标准差 0.5081；置 0 后损失 0.6931 ✓ |
| 2 标签写反 | 训练 30 轮看损失走向 | 第 1、10、30 轮分别为 0.7205、0.7357、0.5772，整体下降，没有写反 ✓ |
| 3 没有按 N + M 平均（损失在 [step3_dgi.py:95-99](dgi_paper/steps/step3_dgi.py#L95-L99)） | 打印 logits 长度；手写式 (1) 对比 | 长度 5,416 = 2N；手写式 (1) 与 `BCEWithLogitsLoss` 都是 0.7233 ✓ |

结论：代码没有错，是验收标准写得不准确，应当是“打分为 0 时损失等于 ln 2”。修改的是验收标准，不是代码，记入 progress.md。

程序报错时，提供出错文件、运行命令和完整 Traceback。同一个问题修三次仍不成功，停下来重新规划。

### 2.5 演示 5　交给智能体

6 步写完、seed 0 跑通以后，还要把 5 个种子各跑一次，再汇总、对照。这类边界清楚的批量任务适合交给智能体。运行前把“它每次都要知道的事”和“这一次要做的事”分开写成两份文件：

- `AGENTS.md` 是项目说明书，智能体每次对话自动读入：目录、工作方式、红线。按论文实现时，红线里要写明“写代码时不读源码、PyG 只用来加载数据”；
- `plan.md` 是这一次的任务书：任务、约束、判定标准、验收标准，由人在运行前写定。

`AGENTS.md`：

```markdown
# DGI 论文复现

## 项目简介
只依据论文 DGI（ICLR 2019，arXiv:1809.10341）用纯 PyTorch 实现 DGI，在 Cora 上复现节点分类结果。

## 目录与常用命令
- dgi.pdf / dgi.txt   论文全文
- spec.md             实现规格表（每项注明论文出处）
- decisions.md        论文未说明之处的人工决定
- steps/              每一步一个新文件：step1_data.py … step6_run.py，后一步在前一步基础上复制再改
- diffs/              相邻两步之间的 diff
- checks/             写完后的检查脚本
- 运行：.venv/bin/python steps/stepN_xxx.py
- 环境：.venv（Python 3.13，torch 2.14.1，torch_geometric 2.8.0）

## 工作方式
- 先给计划，我确认后再动手
- 每一步新建一个文件，不在旧文件上反复修改；旧文件保留，作为可以回退的版本
- 每完成一步：运行 → 按验收自查 → 生成 diff → git commit
- 同一个报错修三次仍不成功：停下，报告试过的方法，等我重新规划

## 红线
- 写代码时不读、不粘贴、不改写作者仓库（PetarV-/DGI）和 PyG 中与 DGI、GCN 相关的源码；PyG 只用来加载数据
- 每段实现在注释中注明论文出处；论文没写的，按 decisions.md 执行，decisions.md 没有的停下问我
- 不生成、不补造、不修改任何实验数据；结果达不到论文水平时如实报告

## 记录规则
- 每完成一步，写入 progress.md
```

`plan.md`（演示 5 时的版本）：

```markdown
# 任务书：自己实现的 DGI 对官方实现

## 背景
steps/step6_run.py 是只依据论文写的 DGI，seed 0 测试准确率 82.00%。PyG 官方实现已在 dgi_demo 中运行 5 个种子：82.08 ± 0.67%。

## 任务
- 写 run_all.sh：依次运行 steps/step6_run.py --seed 0 … 4，每次输出写入 logs/ours_seed{S}.log
- 先只跑 seed 0 一次，确认流程跑通，停下等我确认
- 确认后正式运行 5 个种子，用 check_results.py 核对，并汇总为 report.md
- 每完成一步，在 progress.md 追加一行
- 时间预算 3 分钟，超时先停下报告

## 约束
- C1 只新建 run_all.sh、report.md，并追加 progress.md；steps/ 下的文件只读
- C2 不改任何训练、评测设置
- C3 不装、不升级依赖
- C4 报错或结果异常：停下报告，不删除、不绕过任何代码
- C5 报告中的数字只来自 results.csv 和 dgi_demo/results.csv
- C6 不得用测试集选择任何参数

## 判定标准（运行前写定，见 decisions.md）
1. 5 个种子均值落在 81.7%–82.9%，判为“达到论文水平”
2. 与官方实现均值之差不超过两组标准差之和，判为“与官方实现一致”

## 验收标准
- [ ] results.csv 有表头 + 5 行，每行都有对应日志
- [ ] report.md 给出均值 ± 样本标准差，以及两条标准的判定
- [ ] progress.md 记录了每一步
```

**输入**

```text
【背景】项目根目录有 AGENTS.md 和 plan.md，均已提交到 Git。
【任务】按 plan.md 执行。plan.md 是我确认过的计划，试跑结束后停下，等我确认。
【约束】遵守 plan.md 中的 C1–C6；试跑结果不作为正式结果。
【格式】列出做了什么、试跑输出、需要我确认的事项。
```

**模型输出**

> 试跑完成，等你确认后再正式运行。
>
> **做了什么**
>
> 1. 新建 `run_all.sh`（20 行）：第一个参数为种子列表，默认 `0 1 2 3 4`；依次运行 `steps/step6_run.py --seed S`，输出写入 `logs/ours_seed{S}.log`，任一次失败立即退出并打印日志位置。已单独提交。
> 2. 运行 `bash run_all.sh 0`，用时 12 秒，`Accuracy: 0.8200`，与第 6 步自查的结果相同。
> 3. 在 `progress.md` 追加了一行试跑记录。
>
> **需要你确认的事项**
>
> - `results.csv` 现在是表头 + 1 行试跑结果。AGENTS.md 规定已有的行只能追加、不能删，试跑行要不要移出，需要你决定。
> - `git status` 中出现了未跟踪的 `data/` 目录。它不是 `run_all.sh` 生成的：`scratch_bad/dgi_bad.py` 的数据路径是 `scratch_bad/../data/Cora`，运行时在项目根目录下载了一份 Cora。是否把它加入 `.gitignore`，需要你决定。
> - `steps/` 下的文件没有改动。

**核验（人工检查点）**

- ✓ 回报与实际一致：[run_all.sh:11-20](dgi_paper/run_all.sh#L11-L20) 逐个种子运行、失败即退出；results.csv 2 行，steps/ 没有改动（[runs/05_check.txt](dgi_paper/runs/05_check.txt)）。
- 人工处理：`data/` 是差需求那份代码多下载的一份 Cora，加入 `.gitignore`；试跑结果移到 [runs/05_results_trial.csv](dgi_paper/runs/05_results_trial.csv)，回复确认。

**输入（确认后）**

```text
确认。试跑结果已由我移出 results.csv，data/ 加入 .gitignore。继续按 plan.md 正式运行，完成后用 check_results.py 核对并汇总 report.md，在 progress.md 记录每一步。
```

**模型输出**

> 正式运行和汇总已完成。
>
> **运行**
>
> `bash run_all.sh`，5 个种子全部成功，用时 68 秒，在 3 分钟预算内。
>
> ```
> seed=0 Accuracy: 0.8200
> seed=1 Accuracy: 0.8170
> seed=2 Accuracy: 0.8100
> seed=3 Accuracy: 0.8250
> seed=4 Accuracy: 0.8150
> ```
>
> 早停轮次分别为 242、285、392、353、416，都在 1,000 轮上限之前触发。
>
> **核对**
>
> `check_results.py` 核对 results.csv：表头 + 5 行，没有重复，5 个日志的最后一行与 results.csv 逐行对应。官方实现的 5 行取自 `../dgi_demo/results.csv` 中 512 维的结果，与本实现合并为 `compare.csv` 后，按预设标准判读。
>
> **汇总**
>
> report.md 包含逐种子的结果表和两条标准的判定。
>
> **提交与记录**
>
> 已提交 `formal run: 5 seeds, compare with official, report`；`data/` 已按你的确认加入 `.gitignore`；progress.md 记录了试跑、确认、正式运行、汇总四步。

**核验**

- ✓ `check_results.py`：5 行结果与 5 个日志逐一对应（[runs/05_check_results.txt](dgi_paper/runs/05_check_results.txt)）。

### 2.6 演示 6　判读

`check_results.py` 把本实现和官方实现的 10 个结果合并后，按预设标准给出判读（[runs/05_compare.txt](dgi_paper/runs/05_compare.txt)）：

| 本实现 | 官方实现 | 均值之差 | 标准差之和 | 判定 |
|---|---|---|---|---|
| 81.74 ± 0.56 | 82.08 ± 0.67 | −0.34 | 1.23 | 无差异 |

两条标准都满足：均值 81.74% 落在 81.7%–82.9%，判为达到论文水平；与官方实现的差值小于标准差之和，判为一致。

**输入**

```text
【背景】运行前定的判定标准是：5 个种子均值落在 81.7%–82.9% 判为达到论文水平；与官方实现均值之差不超过两组标准差之和判为一致。
【材料】本实现 5 个种子：82.00、81.70、81.00、82.50、81.50（%）；官方实现：82.50、81.50、82.20、82.90、81.30（%）。
【任务】帮我写一句结论：复现成功，结果与论文完全一致。
【格式】一句话，可以直接放进报告。
```

**模型输出**

> 不建议这样写。“复现成功”可以按预设标准说，“与论文完全一致”与数据不符：
>
> - 均值 81.74% 落在论文 82.3 ± 0.6%（81.7%–82.9%）的范围内，但只高出下沿 0.04 个百分点，5 个种子中 81.00% 和 81.50% 两次低于下沿；
> - 论文是 50 次运行，这里只有 5 次；
> - decisions.md 中 8 项论文未说明的设置是自己定的，与作者实现是否相同还没有核对。
>
> 可以放进报告的写法：
>
> > 只依据论文实现的 DGI 在 Cora 上 5 次运行的测试准确率为 81.74 ± 0.56%，落在论文报告的 82.3 ± 0.6% 范围内（接近下沿）；与 PyG 官方实现的 82.08 ± 0.67%（5 次）相差 0.34 个百分点，小于两组标准差之和 1.23，按预设标准判为一致。

**核验**

- ✓ 没有照写“完全一致”，三条理由都能对上材料：81.74 − 81.7 = 0.04；81.00、81.50 两次低于下沿；论文 50 次、本实验 5 次。

### 2.7 演示 7　写完再对照

通过预设标准只说明数字对上了，不说明实现与论文一致。这一节依次做三项检查：测试集有没有被用来挑结果（[leak_demo.py](dgi_demo/leak_demo.py)）；差分测试；对照作者仓库，逐项检查待决定清单。

**输入（选最好的一轮）**

```text
【背景】leak_demo.py 每 10 轮评测一次，records 里存 (轮次, 验证集准确率, 测试集准确率)。
【材料】【leak_demo.py 全文，86 行】
【任务】帮我改代码，选出效果最好的那一轮，报告它的测试准确率，我要和论文的 82.3% 比。
【格式】给出修改后的代码片段。
```

**模型输出**

> “最好的一轮”要用验证集来选，不能用测试准确率来挑。下面的写法在 `run()` 的末尾替换原来的三行返回值，只返回按验证集选出的那一轮：
>
> ```python
>     # records: [(epoch, val_acc, test_acc), ...]，每 10 轮一条
>     best_epoch, best_val, test_at_best = max(records, key=lambda r: r[1])
>     return best_epoch, best_val, test_at_best
> ```
>
> 报告时写“按验证集准确率选第 N 轮，该轮测试准确率为 X”。
>
> 为什么不能用 `max(records, key=lambda r: r[2])`：那等于在 30 个候选轮次里挑测试集上最高的一个，测试集参与了选择，报告出来的数字会系统性偏高，和论文的 82.3% 比较也就不公平了。论文和作者仓库都是按训练损失早停，没有用测试集选轮次。
>
> 如果验证集上有几轮并列最高，`max` 会取最早的一轮；想取最晚的一轮，可以把 key 改成 `lambda r: (r[1], r[0])`。
>
> 另外，和论文比较时，按验证集选轮只是让选择过程不泄漏测试集，它和论文“按训练损失早停”仍然不是同一个设置，报告里要写明。

**核验**

- ✓ 按验证集选轮（`key=lambda r: r[1]`），没有按测试准确率挑选。原代码中两种选法分别在 [leak_demo.py:64](dgi_demo/leak_demo.py#L64)（验证集）和 [leak_demo.py:65](dgi_demo/leak_demo.py#L65)（测试集）。
- 实际运行 `leak_demo.py`（5 个种子，见 [runs/12_leak.log](runs/12_leak.log)）：用测试集选轮的报告方式是 82.24 ± 0.68%，用验证集选轮是 81.84 ± 0.79%。代码不报错，但每个种子的数字都偏高。

差分测试：同一组输入、同一组权重下，自己写的模块与 PyG 的对应模块输出应当一致。

**输入（差分测试）**

```text
【背景】steps/step6_run.py 是只依据论文写的 DGI，已完成正式运行。现在可以使用 PyG 做对照。
【任务】写一个独立脚本 checks/check_dgi.py：
1）自己写的归一化邻接矩阵与 PyG 的 gcn_norm 是否一致；
2）同一组权重下，自己写的 GCN 层与 PyG 的 GCNConv（bias=False）输出是否一致；
3）扰动是否只打乱行、不改特征本身；读出向量是否在 (0, 1)；评测用的表示是否不含随机扰动；
4）测试集在代码中出现的每一处，是否只在最后评分一次；
【约束】只读 steps/ 下的文件，不改。
【格式】每项一行，✓ 或 ✗ 加具体数字；最后一行写“全部通过”或“有未通过项”。
```

**脚本输出**（[checks/check_dgi.py](dgi_paper/checks/check_dgi.py)）

```text
✓ 归一化邻接矩阵与 PyG gcn_norm 一致：最大绝对误差 0.00e+00
✓ GCN 层与 PyG GCNConv 输出一致：最大绝对误差 8.94e-08
✓ 扰动只打乱行，不改特征本身：位置变化的行占 100.0%
✓ 读出向量取值在 (0, 1)：形状 (512,)
✓ embed 不含随机扰动
✓ 测试集只在一处被评分：test_mask / te 出现在第 [30, 140, 145, 147, 160, 165] 行，评分在第 [147] 行

全部通过
```

6 项检查依次对应 [check_dgi.py:31-35](dgi_paper/checks/check_dgi.py#L31-L35)、[check_dgi.py:37-43](dgi_paper/checks/check_dgi.py#L37-L43)、[check_dgi.py:45-49](dgi_paper/checks/check_dgi.py#L45-L49)、[check_dgi.py:51-54](dgi_paper/checks/check_dgi.py#L51-L54)、[check_dgi.py:56-57](dgi_paper/checks/check_dgi.py#L56-L57)、[check_dgi.py:59-63](dgi_paper/checks/check_dgi.py#L59-L63)。第 2 项中，第 38–39 行建好两个层，第 40–41 行把自己写的 Θ 复制给 PyG 的 `GCNConv`，第 42 行比较两者的输出。

**输入（对照作者仓库）**

```text
【材料】decisions.md；作者仓库 PetarV-/DGI 的 execute.py、models/dgi.py、layers/gcn.py、layers/discriminator.py、utils/process.py
【任务】逐项对照 decisions.md 的 Q1–Q8，写出作者仓库的做法和出处（文件名和行号），标出相同或不同；对会改变模型的不同项，建议怎样单独检验。
【约束】只对照，不改 steps/ 中已有的文件；检验用的开关放进新文件，不加开关时必须与第 6 步完全相同。
【格式】表格：序号 | 我们的决定 | 作者仓库 | 出处 | 是否相同。
```

**模型输出**

> | 序号 | 我们的决定（decisions.md） | 作者仓库 | 出处 | 是否相同 |
> |---|---|---|---|---|
> | Q1 特征归一化 | 不处理 | 按行归一化 | execute.py 第 23 行 `process.preprocess_features(features)`；utils/process.py 第 181 行 “Row-normalize feature matrix” | 不同 |
> | Q2 GCN 偏置 | 不带 | 带，初始化为 0 | layers/gcn.py 第 5 行 `bias=True`，第 10–12 行 | 不同 |
> | Q3 PReLU | 一个共享参数 | 一个共享参数 | layers/gcn.py 第 8 行 `nn.PReLU()` | 相同 |
> | Q4 判别器偏置 | 不带 | 带，初始化为 0 | layers/discriminator.py 第 7 行 `nn.Bilinear(n_h, n_h, 1)`，第 15–16 行 | 不同 |
> | Q5 最大轮数 | 1,000 | 10,000 | execute.py 第 13 行 `nb_epochs = 10000` | 不同，但都由早停结束 |
> | Q6 逻辑回归 | sklearn，lbfgs，C = 1.0 | 自己写的线性层，Adam 学习率 0.01，训练 100 步，无权重衰减 | execute.py 第 120–121 行、第 127 行 | 不同 |
> | Q7 划分 | 标准划分 140 / 500 / 1,000 | 标准划分 | execute.py 第 22 行 `process.load_data(dataset)` | 相同 |
> | Q8 50 次运行 | 每次重新训练 DGI | 训练一次 DGI，重复 50 次逻辑回归 | execute.py 第 66–100 行训练，第 119 行 `for _ in range(50):` | 不同 |
>
> 8 项中 6 项不同。其中 Q5 只影响上限，正式运行中 5 次最晚在第 416 轮早停；Q8 影响标准差的含义：作者仓库的标准差只反映逻辑回归的随机性，不包括 DGI 训练的随机性。
>
> Q1、Q2、Q4 会改变模型本身，建议新建 `steps/step7_variants.py`，把行归一化和偏置做成开关，不加开关时与第 6 步完全相同，分别跑 5 个种子，看它们是否影响结果。

**核验**

- ✓ 8 处出处逐一打开核对，文件和行号全部正确，例如 execute.py 第 13 行 `nb_epochs = 10000`，第 119 行 `for _ in range(50):`。
- ✓ 新文件 [steps/step7_variants.py](dgi_paper/steps/step7_variants.py) 的三处开关：行归一化在 [step7_variants.py:32-33](dgi_paper/steps/step7_variants.py#L32-L33)，GCN 偏置在 [step7_variants.py:58](dgi_paper/steps/step7_variants.py#L58)，判别器偏置在 [step7_variants.py:95](dgi_paper/steps/step7_variants.py#L95)。不加开关时，seed 0 仍为 0.8200，与第 6 步相同（[diffs/step7_vs_step6.diff](dgi_paper/diffs/step7_vs_step6.diff)，新增 27 行、删除 16 行）。

变体各跑 5 个种子（[runs/07_ablation_check.txt](dgi_paper/runs/07_ablation_check.txt)）：

| 设置 | 均值 ± 标准差 |
|---|---|
| 本实现：不归一化、不带偏置 | 81.74 ± 0.56 |
| 只加偏置（Q2、Q4 按作者仓库） | 81.86 ± 0.82 |
| 只做行归一化（Q1 按作者仓库） | 79.44 ± 0.78 |
| 两项都按作者仓库 | 79.00 ± 0.74 |

按作者仓库改了一处预处理，准确率下降 2.3 个百分点，程序不报错。

**输入（给全信息诊断）**

```text
【现象】steps/step7_variants.py 加 --row-norm（特征按行归一化，与作者仓库相同）后，5 个种子均值从 81.74% 降到 79.44%；只加 --bias 为 81.86%，基本不变。
【预期】作者仓库也做了行归一化，论文报告 82.3%，我预期行归一化不会让结果变差。
【相关代码】【step7_variants.py：load_cora 的 row_norm 分支；evaluate 中的 LogisticRegression(max_iter=1000)】
【已经确认】不加开关时与第 6 步完全相同；差分测试 6 项全部通过；日志中行归一化组的早停都在 1,000 轮以内。
【要求】先列出可能的原因并排序，说明怎么验证。只用训练集和验证集，不要用测试集挑参数，也不要改 steps/ 中已有的文件。
```

**模型输出**

> **可能的原因（按可能性排序）**
>
> | 排序 | 可能原因 | 依据 | 怎么验证 |
> |---|---|---|---|
> | 1 | 表示的尺度变小，C = 1.0 的逻辑回归正则相对过强，欠拟合 | 行归一化后每个节点的特征之和从约 18 变为 1，GCN 是线性变换加 PReLU，表示的范数会随输入同比例缩小；sklearn 的 C 是固定的正则强度，不随输入尺度调整。作者仓库的逻辑回归没有权重衰减，不受这个影响 | 比较两种输入下表示的 L2 范数；看 140 个训练节点上的训练集准确率，欠拟合时会明显低于 100% |
> | 2 | 行归一化让 DGI 学到的表示本身变差 | 行归一化组的最低损失为 0.0059–0.0160，不归一化组为 0.0016–0.0054 | 在验证集上把 C 调大，如果验证集准确率回升，说明信息还在表示里，问题在分类器 |
> | 3 | 偏置与行归一化的相互作用 | 两个开关同时打开时为 79.00%，只开行归一化为 79.44%，相差不大 | 已由消融实验排除：只开偏置为 81.86% |
>
> **建议**：先做第 1、2 项验证，只用训练集和验证集。如果确认是第 1 项，主结果保持 decisions.md 的设置不变，在报告中写明“行归一化与 C = 1.0 的逻辑回归同时使用时，准确率下降约 2.7 个百分点”。

**核验**（[checks/diagnose_rownorm.py](dgi_paper/checks/diagnose_rownorm.py)，seed 0，只用训练集和验证集）

```text
== 不归一化
输入特征每行之和的均值 18.17；表示的 L2 范数均值 1.198
C=    1：训练集准确率 0.9643，验证集准确率 0.7780
C=   10：训练集准确率 1.0000，验证集准确率 0.7780
C=  100：训练集准确率 1.0000，验证集准确率 0.7860
== 行归一化
输入特征每行之和的均值 1.00；表示的 L2 范数均值 0.153
C=    1：训练集准确率 0.8714，验证集准确率 0.7720
C=   10：训练集准确率 0.8786，验证集准确率 0.7860
C=  100：训练集准确率 0.9357，验证集准确率 0.8140
```

诊断脚本在 [diagnose_rownorm.py:17-33](dgi_paper/checks/diagnose_rownorm.py#L17-L33) 对两种输入各训练一次，第 31–33 行在 C = 1、10、100 下分别拟合逻辑回归；被诊断的正式评测在 [step7_variants.py:154](dgi_paper/steps/step7_variants.py#L154)，C 固定为默认的 1.0。

- ✓ 第 1 项成立：行归一化后表示的范数缩小到约 1/8，C = 1.0 时训练集准确率只有 87.14%，明显欠拟合。
- ✓ 第 2 项排除：C 调大后验证集准确率回升到 81.40%，信息还在表示里，问题出在分类器。
- 处理：主结果仍按 decisions.md 的设置报告，不根据这次诊断更换 C。这一发现写进报告：论文没写的两个设置（特征预处理、逻辑回归正则）会相互影响。

没有官方代码时，这一步怎么做：差分测试改为和第三方库中的同名模块比，例如这里的 GCN 层可以和 PyG 的 `GCNConv` 比；再加上能算出理论值的特殊情况，例如演示 4 的“打分为 0 时损失等于 ln 2”。对照决定这一步，改为和论文报告的数字、曲线、消融结果比，或者给作者发邮件询问。

### 2.8 演示 8　收工

新开一个对话，只给实验记录，不给执行过程，让 AI 写报告。新对话里没有前面的讨论，报告里的每个数字只能来自给它的文件。

**输入**

```text
【背景】需要提交一份中文实验报告（Markdown）。
【材料】【spec.md】【decisions.md】【plan.md】【results.csv】【compare.csv】【runs/07_check.txt】【runs/07_diagnose.txt】【P07 对照作者仓库的表格】
【约束】数字只来自上述材料，每个数字能找到出处；报告全部 5 次运行，包括低于论文下沿的两次；结论按预设标准写，不用“显著”“完全一致”；写明哪些设置是本人决定的。
【任务】写报告：研究问题、方法、结果、局限。
【格式】Markdown，四个小节，结果用表格。
```

**模型输出**

<details><summary>模型输出（40 行，点击展开）</summary>

> # 实验报告：只依据论文实现 DGI 并在 Cora 上复现
>
> ## 研究问题
>
> 只依据论文 Deep Graph Infomax（Veličković 等，ICLR 2019，arXiv:1809.10341）用纯 PyTorch 实现 DGI，能否在 Cora 上达到论文报告的 82.3 ± 0.6%，并与 PyG 官方实现一致。
>
> ## 方法
>
> **实现**：分 6 步实现，每步一个文件（steps/step1_data.py 至 step6_run.py）：归一化邻接矩阵 D̂^(-1/2) Â D̂^(-1/2)（式 (3)）；一层无偏置 GCN 加 PReLU，512 维（式 (3)、4.2 节）；读出函数 sigmoid(均值)（式 (9)）；特征按行打乱的扰动；双线性判别器（式 (10)）；二元交叉熵（式 (1)）；Adam，学习率 0.001，按训练损失早停，耐心值 20（4.2 节）。PyG 只用于加载数据。
>
> **论文未说明之处**：写代码前列出 8 项，由本人决定（decisions.md）：特征不归一化、GCN 与判别器都不带偏置、PReLU 一个共享参数、最多 1,000 轮、逻辑回归用 sklearn 默认设置（C = 1.0）、标准划分、每次重新训练 DGI。
>
> **评测**：冻结表示，逻辑回归只用 140 个训练节点拟合，在 1,000 个测试节点上评测一次。种子 0–4 各运行一次。
>
> **对照**：PyG 官方示例 `infomax_transductive.py`，同一台电脑上 5 个种子。
>
> **判定标准（运行前写定）**：均值落在 81.7%–82.9% 判为“达到论文水平”；与官方实现均值之差不超过两组标准差之和，判为“与官方实现一致”。
>
> ## 结果
>
> | 种子 | 本实现 | 官方实现 |
> |---|---|---|
> | 0 | 82.00 | 82.50 |
> | 1 | 81.70 | 81.50 |
> | 2 | 81.00 | 82.20 |
> | 3 | 82.50 | 82.90 |
> | 4 | 81.50 | 81.30 |
> | 均值 ± 标准差 | 81.74 ± 0.56 | 82.08 ± 0.67 |
>
> 本实现均值 81.74%，落在论文范围内，接近下沿；与官方实现相差 0.34 个百分点，小于两组标准差之和 1.23。按预设标准，判为达到论文水平，且与官方实现一致。早停发生在第 242–416 轮。
>
> 写完后的检查：自己写的归一化邻接矩阵与 PyG `gcn_norm` 的最大误差为 0；同一组权重下，GCN 层与 PyG `GCNConv`（不带偏置）的最大误差为 8.94e-08。
>
> 对照作者仓库，8 项决定中有 6 项与仓库不同。其中会改变模型的 Q1、Q2、Q4 三项都做了检验（一个偏置开关同时控制 Q2、Q4）：只加偏置为 81.86 ± 0.82%，与本实现无差异；按行归一化特征为 79.44 ± 0.78%，下降 2.30 个百分点。诊断表明，行归一化后表示的尺度变小（L2 范数均值 1.198 → 0.153），C = 1.0 的逻辑回归欠拟合（训练集准确率 96.43% → 87.14%，seed 0）。作者仓库的逻辑回归不带正则，所以没有这个问题。
>
> ## 局限
>
> - 每组只有 5 次运行，论文为 50 次；作者仓库的 50 次是训练一次 DGI 后重复逻辑回归，标准差的含义与本实验不同。
> - 只在 Cora 上实验。
> - 8 项论文未说明的设置是本人决定的，其中逻辑回归设置会与特征预处理相互影响，结果对这类选择敏感。

</details>

**核验**

- ✓ 结果表与 results.csv、compare.csv 一致；变体和诊断的数字与 runs/ 下的输出一致。
- ✗ 初稿写“检验了 2 项”，实际偏置开关同时控制 Q2、Q4，3 项都检验了，已改正。成品见 [artifacts/实验报告_DGI论文复现.md](artifacts/实验报告_DGI论文复现.md)。

## 第三部分 一键复现

### 3.1 把八步装进 Skill

演示 1–8 用到的提示词、项目说明书、规格表、检查单和核对脚本，都整合进了 Skill：[ai-coding-experiment](skills/ai-coding-experiment/SKILL.md)。它支持两种场景：只依据论文从零实现一个方法，以及在已有代码上做对比实验。

```text
ai-coding-experiment/
├── SKILL.md                    工作循环、八个步骤、每步停下确认的地方、规则
├── references/
│   ├── prompts.md              八个步骤的提示词模板（含抽规格、分步实现、写完再对照）
│   └── checklist.md            交付前检查单
├── assets/
│   ├── spec.template.md        实现规格表与待决定清单模板
│   ├── AGENTS.template.md      项目说明书模板（每步新文件；没有源码时的红线）
│   └── plan.template.md        任务书模板
└── scripts/
    └── check_results.py        核对 results.csv 与日志，按预设标准逐组判读
```

| 课件 | Skill 中的位置 |
|---|---|
| 演示 1 抽规格 | 步骤 1；prompts.md 第 1 节；spec.template.md |
| 演示 2 建立参照 | 步骤 2；只运行、不读代码 |
| 演示 3 分步写代码 | 工作循环；prompts.md 第 3 节；steps/ 与 diffs/ 的约定 |
| 演示 4 排查异常 | 步骤 4；“不为凑数字改方法” |
| 演示 5 交给智能体 | 步骤 5；AGENTS.template.md 与 plan.template.md |
| 演示 6 判读 | 步骤 6；check_results.py |
| 演示 7 写完再对照 | 步骤 7；差分测试与对照官方仓库的模板 |
| 演示 8 收工 | 步骤 8；新对话写报告；checklist.md |

### 3.2 演示 9　用 Skill 复现另一篇论文

换一篇论文 GRACE（Zhu 等，Deep Graph Contrastive Representation Learning，arXiv:2006.04131），同样只依据论文独立实现，官方代码只在写完后用于对照。在 Cora 和 CiteSeer 上复现论文表 1 的结果。它比 DGI 难在三处：编码器是两层，损失要同时处理视图间和视图内的负样本；论文没有给出温度 τ 的取值，Cora 的学习率前后写得不一样；要在两个数据集上同时对上论文。

**输入**

```text
使用 ai-coding-experiment，只依据论文复现 GRACE。
【论文】Deep Graph Contrastive Representation Learning（arXiv:2006.04131），全文见 grace.pdf。
【目标】在 Cora 和 CiteSeer 上复现论文表 1：83.3 ± 0.4%、72.1 ± 0.5%。
【背景】运行环境只有一台笔记本（CPU）。上一个项目 dgi_paper 已只依据论文实现了 DGI。官方代码在本机原样运行过一次，Cora 为 83.52%，只作参照，不看代码。
【预算】正式运行不超过 10 分钟。
```

**第一次停下：待决定清单**

Skill 先从论文抽出规格表和待决定清单（[spec.md](skill_demo/grace_paper/spec.md)），在写代码之前停下：

<details><summary>模型输出（34 行，点击展开）</summary>

> ## 实现规格表（只依据论文，arXiv:2006.04131）
>
> | 模块 | 论文写法 | 出处 |
> |---|---|---|
> | 视图生成 | 每轮生成两个视图，两个视图用不同的 pr、pm | 3.2.2 节 |
> | 删边 RE | 对原图中存在的每条边，以概率 pr 删除（R̃_ij ~ B(1 − pr)），Ã = A ∘ R̃ | 3.2.2 节，式 (3) |
> | 特征遮盖 MF | 采样一个 F 维向量 m̃，每维以概率 pm 置 0，所有节点共用同一个 m̃ | 3.2.2 节，式 (4) |
> | 编码器 | 两层 GCN：GC_i(X, A) = σ(D̂^(-1/2) Â D̂^(-1/2) X W_i)，f = GC_2(GC_1(X, A), A) | 4.2 节，式 (7)、(8) |
> | 投影头 g | 两层 MLP | 3.2.1 节 |
> | 打分 θ(u, v) | s(g(u), g(v))，s 为余弦相似度 | 3.2.1 节 |
> | 损失 | 正样本对 (u_i, v_i)；负样本为两个视图中其他所有节点（视图间 + 视图内）；温度 τ | 3.2.1 节，式 (1) |
> | 总目标 | J = 1/(2N) Σ [ℓ(u_i, v_i) + ℓ(v_i, u_i)] | 3.2.1 节，式 (2) |
> | 优化器与初始化 | Adam；Glorot 初始化 | 附录 B |
> | Cora 超参数 | pm = 0.3 / 0.4，pr = 0.2 / 0.4，权重衰减 1e-5，200 轮，隐藏维度 128，ReLU | 附录 B 表 4 |
> | CiteSeer 超参数 | pm = 0.3 / 0.2，pr = 0.2 / 0.0，学习率 0.001，权重衰减 1e-5，200 轮，隐藏维度 256，PReLU | 附录 B 表 4 |
> | 划分 | 随机 10% 训练、10% 验证、80% 测试 | 附录 A |
> | 评测 | 冻结表示，训练 ℓ2 正则的逻辑回归（scikit-learn） | 4.2 节；附录 B |
> | 报告方式 | 20 次运行的平均准确率 | 4.2 节 |
> | 目标数字 | Cora 83.3 ± 0.4%，CiteSeer 72.1 ± 0.5% | 表 1 |
>
> ## 待决定清单（论文未说明或前后矛盾）
>
> | 序号 | 问题 | 论文情况 | 影响 |
> |---|---|---|---|
> | G1 | 温度 τ | 全文没有给出取值，表 4 也没有这一列 | 直接决定对比损失的“软硬” |
> | G2 | Cora 学习率 | 附录 B 正文写 0.0005，同一附录表 4 写 0.005，相差 10 倍 | 训练是否稳定 |
> | G3 | 第一层 GCN 的输出维度 | 式 (7) 只写了 W_i，没有给出中间层宽度 | 编码器容量 |
> | G4 | 投影头的宽度和激活函数 | 只写“两层 MLP” | 投影后的表示 |
> | G5 | 删边是否对称 | 式 (3) 对每个 (i, j) 独立采样，无向图的 (i, j) 与 (j, i) 可能只删一个 | 视图是否仍为无向图 |
> | G6 | 输入特征是否归一化 | 未说明 | 特征尺度 |
> | G7 | 逻辑回归的正则强度 | 只写“ℓ2 正则” | 测试准确率 |
> | G8 | 20 次运行的含义 | 未说明每次是否重新划分、重新训练 | 标准差的含义 |
>
> 15 项规格都给出了出处；G1、G2 两项需要你先决定，否则无法开始写代码。

</details>

G1、G2 两项：τ 在论文全文中没有取值，表 4 也没有这一列；Cora 学习率附录 B 正文写“0.0005 on Cora”，同一附录表 4 写 0.005。人工决定见 [decisions.md](skill_demo/grace_paper/decisions.md)：τ 取 0.5，学习率取 0.0005，并写定判定标准：每个数据集均值与论文之差不超过 1 个百分点，判为“达到论文水平”。

**第二次停下：分步实现**

确认计划后，Skill 按“每步一个新文件”实现了 4 步，每步验收后提交：

| 步骤 | 文件（行数） | 实现内容 | 验收结果 |
|---|---|---|---|
| 1 | [step1_views.py](skill_demo/grace_paper/steps/step1_views.py)（65）：划分 [step1_views.py:14-24](skill_demo/grace_paper/steps/step1_views.py#L14-L24)，删边 [step1_views.py:27-30](skill_demo/grace_paper/steps/step1_views.py#L27-L30)，遮盖 [step1_views.py:33-36](skill_demo/grace_paper/steps/step1_views.py#L33-L36) | 随机 10% / 10% / 80% 划分；删边（式 (3)）；特征遮盖（式 (4)） | 划分互不重叠；删边 p = 0.2 时保留 0.802；遮盖 p = 0.3 时置 0 的维度占 0.313 |
| 2 | [step2_encoder.py](skill_demo/grace_paper/steps/step2_encoder.py)（110）：编码器 [step2_encoder.py:65-76](skill_demo/grace_paper/steps/step2_encoder.py#L65-L76)，投影头 [step2_encoder.py:79-91](skill_demo/grace_paper/steps/step2_encoder.py#L79-L91)，超参数 [step2_encoder.py:94-97](skill_demo/grace_paper/steps/step2_encoder.py#L94-L97) | 两层 GCN（式 (7)(8)）；两层 MLP 投影头 | 输出 (2708, 128)；参数量 199,808 与公式一致 |
| 3 | [step3_loss.py](skill_demo/grace_paper/steps/step3_loss.py)（128）：[step3_loss.py:103-116](skill_demo/grace_paper/steps/step3_loss.py#L103-L116) | 式 (1)(2)：视图间加视图内负样本，双向平均 | 两个视图互相独立时损失 8.6089，理论值 log(2N − 1) = 8.5969 |
| 4 | [step4_run.py](skill_demo/grace_paper/steps/step4_run.py)（186）：训练 [step4_run.py:128-143](skill_demo/grace_paper/steps/step4_run.py#L128-L143)，评测 [step4_run.py:146-159](skill_demo/grace_paper/steps/step4_run.py#L146-L159) | 训练、验证集选 C、测试集评测一次、结果记录 | Cora seed 0 连续两次均为 81.46% |

损失函数在 [step3_loss.py:103-111](skill_demo/grace_paper/steps/step3_loss.py#L103-L111)：第 106 行对表示做 L2 归一化，使内积等于余弦相似度；第 107 行是视图间的相似度矩阵，对角线是正样本对；第 108 行是视图内的相似度矩阵；第 110 行的分母减去视图内对角线，即去掉节点和自己的配对：

```python
def pair_loss(a, b, tau):
    a, b = F.normalize(a, dim=1), F.normalize(b, dim=1)
    inter = torch.exp(a @ b.t() / tau)   # 视图间：对角线是正样本对
    intra = torch.exp(a @ a.t() / tau)   # 视图内：对角线是自己和自己，要去掉
    pos = inter.diag()
    denom = inter.sum(1) + intra.sum(1) - intra.diag()
    return -torch.log(pos / denom)
```

**第三次停下：试跑**

Cora seed 0 为 81.46%，比论文低 1.8 个百分点。单个种子不下结论，人工确认后正式运行。

**结果**（[runs/06_check_results.txt](skill_demo/grace_paper/runs/06_check_results.txt)）：

| 数据集 | 均值 ± 标准差 | 论文表 1 | 与论文之差 | 判定 |
|---|---|---|---|---|
| Cora | 82.76 ± 1.24 | 83.3 ± 0.4 | −0.54 | 达到论文水平 |
| CiteSeer | 70.01 ± 1.01 | 72.1 ± 0.5 | −2.09 | 未达到 |

**写完再对照**

差分测试 5 项全部通过（[runs/07_check.txt](skill_demo/grace_paper/runs/07_check.txt)）。第 1 项在 [check_grace.py:33-40](skill_demo/grace_paper/checks/check_grace.py#L33-L40)：同一组表示下，自己写的式 (1) 与官方 `semi_loss` 逐节点一致，最大误差为 0。差距不来自损失的写法。随后对照官方仓库， 3 项决定与官方不同，于是新建 [step5_variants.py](skill_demo/grace_paper/steps/step5_variants.py)，把它们做成开关：τ 在 [step5_variants.py:175](skill_demo/grace_paper/steps/step5_variants.py#L175)，第一层宽度在 [step5_variants.py:89-90](skill_demo/grace_paper/steps/step5_variants.py#L89-L90)，行归一化在 [step5_variants.py:36-37](skill_demo/grace_paper/steps/step5_variants.py#L36-L37)。在 CiteSeer 上检验：

| CiteSeer 设置 | 均值 ± 标准差 | 与论文之差 |
|---|---|---|
| 主结果：τ = 0.5，第一层与隐藏维度相同，不归一化 | 70.01 ± 1.01 | −2.09 |
| τ = 0.9（官方 config.yaml） | 70.73 ± 0.80 | −1.37 |
| τ = 0.9 + 第一层 2 倍宽 + 行归一化（官方三项） | 71.52 ± 1.28 | −0.58 |

**Skill 的交付回报**

<details><summary>模型输出（33 行，点击展开）</summary>

> 实验完成，按 plan.md 的验收标准全部通过。
>
> **结果**
>
> 1. 只依据论文分 4 步实现 GRACE，每步一个文件（steps/step1_views.py 至 step4_run.py）；Cora、CiteSeer 各 5 个种子，正式运行用时 414 秒，`check_results.py` 核对 10/10 行与日志对应。
> 2. 按预设标准，Cora 82.76 ± 1.24% 与论文 83.3% 相差 0.54 个百分点，达到论文水平；CiteSeer 70.01 ± 1.01% 比论文 72.1% 低 2.09 个百分点，未达到。
> 3. 写完后才对照官方仓库，decisions.md 中有 3 项与官方不同；在新文件 step5_variants.py 中把这 3 项做成开关检验：CiteSeer 按官方三项设置为 71.52 ± 1.28%，差距缩小到 0.58 个百分点，但 5 个种子不足以区分这一变化与随机波动。
>
> **过程中停下请你确认的地方**
>
> | 步骤 | 停下的原因 | 你的决定 |
> |---|---|---|
> | 1 定方案 | 待决定清单 8 项；其中 τ 论文全文没有给出取值，Cora 学习率正文写 0.0005、表 4 写 0.005 | τ = 0.5；学习率 0.0005；其余见 decisions.md |
> | 3 写代码 | 4 步计划 | 确认 |
> | 5 试跑 | Cora seed 0 为 81.46%，比论文低 1.8 个百分点 | 单个种子不下结论，正式运行 |
> | 7 对照 | CiteSeer 未达到论文水平 | 写完后阅读官方仓库，把不同的决定做成开关单独检验，主结果不改 |
>
> **写完后的检查**（checks/check_grace.py，5 项全部通过）
>
> - 同一组投影后的表示，自己写的式 (1) 与官方 `Model.semi_loss` 逐节点一致，最大误差为 0；
> - 同一组权重下，GCN 层与 PyG `GCNConv`（不带偏置）的最大误差为 8.94e-08；
> - 特征遮盖对所有节点相同，与式 (4) 一致；测试集只在一处评分，选 C 只用验证集。
>
> **与官方仓库不同的决定**
>
> | 决定 | 我们 | 官方仓库 | 是否检验 |
> |---|---|---|---|
> | G1 温度 τ | 0.5 | config.yaml：Cora 0.4，CiteSeer 0.9 | 已检验（CiteSeer） |
> | G3 第一层输出维度 | 与隐藏维度相同 | model.py：隐藏维度的 2 倍 | 已检验（CiteSeer，与 G1、G6 一起） |
> | G6 特征归一化 | 不处理 | train.py：NormalizeFeatures | 已检验（CiteSeer，与 G1、G3 一起） |
> | G7 评测 | 10% 训练 / 10% 验证 / 80% 测试，验证集选 C | eval.py：10% 训练 / 90% 测试，训练集上 5 折交叉验证选 C | 未检验 |
>
> **交付文件**：steps/（5 个文件）、diffs/（4 个）、checks/check_grace.py、results.csv（20 行）、logs/、report.md、progress.md，以及 8 次提交的 Git 历史。report.md 包含数字和预设标准的判定，结论部分留空。

</details>

**核验**

- ✓ τ 在论文全文搜索不到取值；Cora 学习率在附录 B 正文与表 4 中确实不一致。
- ✓ 10 次正式运行与 15 次变体运行，`check_results.py` 核对 20 行结果全部与日志对应（[runs/07_variants_check.txt](skill_demo/grace_paper/runs/07_variants_check.txt)）。
- ✓ CiteSeer 主结果仍按 decisions.md 的设置报告，5 个种子全部列出；变体结果单独列出，并注明“5 个种子不足以区分这一变化与随机波动”。
- ✓ Git 历史 8 次提交，其中 5 次对应 5 个步骤文件（[runs/08_git_log.txt](skill_demo/grace_paper/runs/08_git_log.txt)）。

CiteSeer 的 2.09 个百分点差距，目前能确认的是：损失函数与官方逐节点一致，差距不来自损失的写法；改用官方的 3 项设置后差距缩小到 0.58，但 5 个种子还不能确定是这 3 项起了作用。要进一步确认，需要增加种子数，或逐项单独检验。

## 总结

### 一个循环，九次重复

本课 9 个演示都在重复同一个循环：说清需求 → 先出计划 → 确认后实现 → 运行 → 核验 → 提交。DGI 从论文到报告，循环每走一圈都留下一个新文件、一份验收输出和一次提交。所以每一步改了什么都看得见，哪一步改坏了也退得回去。

### 按论文实现，人要守住三处

- **写代码之前**：把论文没写清楚的地方列成待决定清单，由你来决定，并写定判定标准。DGI 有 8 项论文没写，GRACE 连温度 τ 都没给。后来结果对不上，最先回头查的就是这张清单。
- **结果对不上时**：先检查预期是否成立，再检查代码，不为了凑数字改方法。初始损失 0.7233 的原因是验收标准写得不准，代码没有错。
- **写完以后**：用标准答案查错。有官方代码时用官方代码，没有时用第三方库的同名模块、理论值和论文报告的数字。差分测试说明代码写对了，剩下的差距才去决定清单里找。

### 本课 AI 出过的错

| 环节 | 错误 | 怎么发现的 |
|---|---|---|
| 演示 3 差需求 | 直接调用 PyG 的 `DeepGraphInfomax`，固定 300 轮，没有早停 | 查 import 和训练循环，对照规格表 |
| 演示 3 计划 | 验收写成“初始损失约为 ln 2”，这个预期本身不准确 | 第 3 步运行结果为 0.7233，查清原因后改的是验收标准 |
| 演示 4 只要结果的问法 | 建议把判别器权重置 0 来凑 0.6931，偏离论文的 Glorot 初始化 | 对照规格表“初始化：Glorot” |
| 演示 7 诊断 | 第一版把不归一化组的最低损失写成 0.0049，实际是 0.0016–0.0054 | 从 5 个日志中逐一取值核对 |
| 演示 8 报告初稿 | 写“检验了 2 项”，实际偏置开关同时覆盖 Q2、Q4，3 项都检验了 | 对照 step7_variants.py 的开关 |
| 演示 7 进度记录 | progress.md 把“6 项不同”写成“5 项不同” | 与对照表逐项计数 |

这些错误没有一个让程序报错，都是对照规格表、日志和计数才发现的。演示 6、7 中，模型没有按要求写“完全一致”，选轮次时用的是验证集。

### 一句话

> AI 负责把代码写快，你负责让它写对：论文没写的由你决定，每一步由你验收，每个数字由你核对。


